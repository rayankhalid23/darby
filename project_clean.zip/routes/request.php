<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\Parent\ParentSubscriptionController;
use App\Http\Controllers\API\Driver\DriverSubscriptionController;
use App\Http\Controllers\API\Shared\ContractController;
use App\Http\Controllers\Api\Shared\ChatController;
use App\Http\Controllers\API\Driver\DriverRouteController;
use App\Http\Controllers\Api\Trip\DriverTripController;


Route::middleware('auth:sanctum')->group(function () {

    // ============================================================
    // مسارات العقود (Shared)
    // ============================================================
    Route::prefix('contracts')->group(function () {
        // الآن المسار سيكون: /api/contracts/{id}/pdf
        Route::get('/{id}/pdf', [ContractController::class, 'generatePdf']);
        
        // المسار سيكون: /api/contracts/clauses
        Route::get('/clauses', [ContractController::class, 'clauses']);
        
        // المسار سيكون: /api/contracts
        Route::post('/', [ContractController::class, 'store']);
        
        // المسار سيكون: /api/contracts/{id}
        Route::get('/{id}', [ContractController::class, 'show']);
        
        // المسار سيكون: /api/contracts/{id}/accept
        Route::put('/{id}/accept', [ContractController::class, 'accept']);
        
        // المسار سيكون: /api/contracts/{id}/reject
        Route::put('/{id}/reject', [ContractController::class, 'reject']);
    });

    // ============================================================
    // مسارات أولياء الأمور لإرسال واستعراض طلبات الاشتراك
    // ============================================================
    Route::prefix('parent')->group(function () {

    Route::post('/', [ParentSubscriptionController::class, 'store']); 
        // المسار الموحد لجلب طلبات الاشتراك (الطلبات الأولية المعلقة والمرفوضة)
        Route::get('/requests', [ParentSubscriptionController::class, 'index']); 
        // مسار إلغاء طلب الاشتراك (المعلق)
        Route::post('requests/{id}/cancel', [ParentSubscriptionController::class, 'cancel']);
        
        // المسار الموحد والوحيد الجديد لجلب الاشتراكات المفعّلة والموافَق عليها بالفلاتر
        Route::get('/active-subscriptions', [ParentSubscriptionController::class, 'activeSubscriptions']); 
              // المسار الخاص بجلب تفاصيل اشتراك نشط معين
              Route::get('/active-subscriptions/{id}', [ParentSubscriptionController::class, 'showActive']);
              Route::get('/chats', [ChatController::class, 'getParentChatList']);
              //مش خادمه الدوال متعها مسار بس
              Route::post('/active-subscriptions/{id}/cancel', [ParentSubscriptionController::class, 'cancelActiveSubscription']);
        
        
        Route::get('/requests/{id}', [ParentSubscriptionController::class, 'showRequest']); 
        
    });

    // ============================================================
    // مسارات السائقين المحدثة
    // ============================================================
    Route::prefix('driver')->group(function () {
        // 1. مسارات ثابتة (Static Routes) - توضع أولاً
        
        // المسار الموحد الجديد لجلب طلبات الاشتراك المبدئية بالفلاتر
        Route::get('/requests', [DriverSubscriptionController::class, 'index']); 
        Route::get('/requests/{id}/trip-details', [DriverSubscriptionController::class, 'tripDetails']);
        Route::get('/requests/{id}', [DriverSubscriptionController::class, 'show']);
        
        // المسار الموحد الجديد لجلب الاشتراكات الفعلية والمثبتة بالفلاتر
        Route::get('/active-subscriptions', [DriverSubscriptionController::class, 'activeSubscriptions']); 
        Route::get('/active-subscriptions/{id}', [DriverSubscriptionController::class, 'activeSubscriptionDetails']);
        Route::get('/chats', [ChatController::class, 'getDriverChatList']);
  
        
        Route::get('/routes', [DriverRouteController::class, 'index']); 
        Route::post('/trips/start', [DriverTripController::class, 'startTrip']);
        
        // 2. مسارات تحتوي على متغيرات (Dynamic Parameters) - توضع أخيراً
        Route::put('/routes/{route}', [DriverRouteController::class, 'update']);
        Route::put('{id}/status', [DriverSubscriptionController::class, 'updateStatus']); 
    });
    
});